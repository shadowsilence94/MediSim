###Instructions for Draft compilation
'Draft_latex' folder contains the raw LaTeX files (report.tex, acl.sty, references.bib).

To compile the LaTeX source, run:

pdflatex report.tex
bibtex report
pdflatex report.tex
pdflatex report.tex

Then the report PDF comes out.